MDB 5 Vue

Version: FREE 1.14.0

Documentation:
https://mdbootstrap.com/docs/b5/vue/

Installation:
https://mdbootstrap.com/docs/b5/vue/getting-started/installation/

CLI & hosting:
https://mdbootstrap.com/docs/standard/cli/

Support:
https://mdbootstrap.com/support/cat/vue/